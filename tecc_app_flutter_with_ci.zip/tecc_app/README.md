# TECC Trainer (Flutter)
- Learn & Assistant modes for TECC MARCH(E)
- Module M fully implemented (PL/EN), offline JSON content, neutral SVGs

## Run
flutter pub get
flutter run

## Build APK
flutter build apk --release

See README_BUILD_APK.md for CI build on GitHub.
