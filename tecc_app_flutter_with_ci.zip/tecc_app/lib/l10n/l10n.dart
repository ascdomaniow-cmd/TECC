import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

class S {
  S(this.localeName);
  final String localeName;

  static const supportedLocales = <Locale>[Locale('en'), Locale('pl')];
  static const localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ];

  static S of(BuildContext context) => Localizations.of<S>(context, S) ?? S('en');
  static Future<S> load(Locale locale) async {
    final name = (locale.countryCode?.isEmpty ?? true) ? locale.languageCode : locale.toString();
    Intl.defaultLocale = Intl.canonicalizedLocale(name);
    return S(Intl.defaultLocale ?? 'en');
  }

  static const LocalizationsDelegate<S> delegate = _SDelegate();

  String t(String key) {
    const en = {
      "appTitle":"TECC Trainer","modeLearn":"Learn","modeAssistant":"Assistant","moduleM":"M — Massive hemorrhage",
      "startModule":"Start module","continueModule":"Continue","lessons":"Lessons","quiz":"Quiz","next":"Next",
      "back":"Back","startQuiz":"Start quiz","correct":"Correct","incorrect":"Incorrect","summary":"Summary","score":"Score",
      "assistantTitle":"Assistant — M (Massive hemorrhage)","assistantIntro":"Follow the steps. Mark each action when done. Use voice prompts if needed.",
      "stepTourniquet":"Apply tourniquet (high & tight)","stepDirectPressure":"Apply direct pressure","stepGauze":"Pack the wound with hemostatic gauze",
      "markDone":"Mark done","voiceHint":"Play voice hint","moduleMIntro":"Goal: recognize and control massive hemorrhage quickly to prevent death from bleeding.",
      "lesson11":"Recognize massive hemorrhage","lesson12":"Tourniquet — when and how","lesson13":"Direct pressure — technique",
      "lesson14":"Hemostatic gauze — application","lesson15":"Common mistakes & tips","finishModule":"Finish module","switchLang":"Language",
      "homeIntro":"Choose a mode to begin. The app works offline."
    };
    const pl = {
      "appTitle":"TECC Trener","modeLearn":"Nauka","modeAssistant":"Asystent","moduleM":"M — Masywny krwotok",
      "startModule":"Rozpocznij moduł","continueModule":"Kontynuuj","lessons":"Lekcje","quiz":"Quiz","next":"Dalej",
      "back":"Wstecz","startQuiz":"Start quizu","correct":"Poprawna","incorrect":"Niepoprawna","summary":"Podsumowanie","score":"Wynik",
      "assistantTitle":"Asystent — M (Masywny krwotok)","assistantIntro":"Postępuj według kroków. Odhaczaj wykonane działania. Użyj podpowiedzi głosowych, jeśli potrzeba.",
      "stepTourniquet":"Załóż opaskę uciskową (wysoko i mocno)","stepDirectPressure":"Zastosuj ucisk bezpośredni","stepGauze":"Zapakuj ranę gazą hemostatyczną",
      "markDone":"Zaznacz wykonano","voiceHint":"Odtwórz podpowiedź głosową","moduleMIntro":"Cel: szybkie rozpoznanie i opanowanie masywnego krwotoku, aby zapobiec zgonowi z wykrwawienia.",
      "lesson11":"Rozpoznanie masywnego krwotoku","lesson12":"Opaska uciskowa — kiedy i jak","lesson13":"Ucisk bezpośredni — technika",
      "lesson14":"Gaza hemostatyczna — aplikacja","lesson15":"Najczęstsze błędy i wskazówki","finishModule":"Zakończ moduł","switchLang":"Język",
      "homeIntro":"Wybierz tryb, aby rozpocząć. Aplikacja działa offline."
    };
    return localeName.startsWith('pl') ? (pl[key] ?? en[key] ?? key) : (en[key] ?? key);
  }
}

class _SDelegate extends LocalizationsDelegate<S> {
  const _SDelegate();
  @override
  bool isSupported(Locale locale)=>['en','pl'].contains(locale.languageCode);
  @override
  Future<S> load(Locale locale)=>S.load(locale);
  @override
  bool shouldReload(_SDelegate old)=>false;
}
