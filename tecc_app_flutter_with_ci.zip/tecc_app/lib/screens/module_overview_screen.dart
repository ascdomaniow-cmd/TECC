import 'package:flutter/material.dart';
import '../l10n/l10n.dart';
import '../services/content_loader.dart';
import '../models/lesson.dart';
import 'lesson_screen.dart';

class ModuleOverviewScreen extends StatefulWidget{
  final Locale locale; const ModuleOverviewScreen({super.key, required this.locale});
  @override State<ModuleOverviewScreen> createState()=>_ModuleOverviewScreenState();
}
class _ModuleOverviewScreenState extends State<ModuleOverviewScreen>{
  late Future<List<Lesson>> _future;
  @override void initState(){ super.initState(); _future = ContentLoader.loadModuleM(widget.locale.languageCode); }
  @override Widget build(BuildContext context){
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('moduleM'))),
      body: FutureBuilder<List<Lesson>>(future: _future, builder: (context, snap){
        if(!snap.hasData) return const Center(child:CircularProgressIndicator());
        final lessons = snap.data!;
        return ListView.builder(itemCount: lessons.length, itemBuilder: (context, i){
          final l = lessons[i];
          return Card(child: ListTile(
            title: Text(S.of(context).t(l.titleKey)),
            subtitle: Text("${S.of(context).t('lessons')} ${i+1}/${lessons.length}"),
            trailing: const Icon(Icons.chevron_right),
            onTap: (){ Navigator.of(context).push(MaterialPageRoute(builder: (_)=>LessonScreen(lesson:l, index:i, total:lessons.length, locale: widget.locale))); },
          ));
        });
      }),
    );
  }
}
