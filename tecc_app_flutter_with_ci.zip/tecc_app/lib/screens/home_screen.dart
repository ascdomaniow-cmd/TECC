import 'package:flutter/material.dart';
import '../l10n/l10n.dart';
import '../theme.dart';
import 'module_overview_screen.dart';
import 'assistant_screen.dart';

class HomeScreen extends StatefulWidget{ const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{
  Locale _locale = const Locale('pl');
  @override Widget build(BuildContext context){
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('appTitle')), actions: [
        DropdownButton<Locale>(value: _locale, underline: const SizedBox.shrink(), onChanged: (loc){
          if(loc!=null){ setState(()=>_locale=loc); }
        }, items: const [ DropdownMenuItem(value: Locale('pl'), child: Text('PL')), DropdownMenuItem(value: Locale('en'), child: Text('EN')) ])
      ]),
      body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(s.t('homeIntro'), style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 24),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(s.t('moduleM'), style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          ElevatedButton(onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>ModuleOverviewScreen(locale:_locale)));
          }, child: Text(s.t('startModule'))),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>AssistantScreen(locale:_locale)));
          }, child: Text(s.t('modeAssistant'))),
        ])))
      ])),
    );
  }
}
