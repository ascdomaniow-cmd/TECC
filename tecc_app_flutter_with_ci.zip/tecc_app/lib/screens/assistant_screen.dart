import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../l10n/l10n.dart';
import '../services/tts_service.dart';

class AssistantScreen extends StatefulWidget{
  final Locale locale; const AssistantScreen({super.key, required this.locale});
  @override State<AssistantScreen> createState()=>_AssistantScreenState();
}
class _AssistantScreenState extends State<AssistantScreen>{
  final _tts = TtsService();
  final List<_StepItem> _steps = [];
  int _current = 0;
  @override void initState(){
    super.initState();
    _steps.addAll([
      _StepItem('stepTourniquet','assets/images/m_opaska.svg'),
      _StepItem('stepDirectPressure','assets/images/m_ucisk.svg'),
      _StepItem('stepGauze','assets/images/m_gaza.svg'),
    ]);
  }
  @override Widget build(BuildContext context){
    final s = S.of(context); final st = _steps[_current];
    return Scaffold(appBar: AppBar(title: Text(s.t('assistantTitle'))),
      body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children:[
        Text(s.t('assistantIntro')),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children:[
          SvgPicture.asset(st.image, height: 160),
          const SizedBox(height: 12),
          Text('• ${s.t(st.key)}'),
          const SizedBox(height: 12),
          Row(children:[
            Expanded(child: ElevatedButton(onPressed: ()=>_speak(s.t(st.key)), child: Text(s.t('voiceHint')))),
            const SizedBox(width: 12),
            Expanded(child: OutlinedButton(onPressed: _markDone, child: Text(s.t('markDone'))))
          ])
        ]))),
        const Spacer(),
        Row(children:[
          if(_current>0) Expanded(child: OutlinedButton(onPressed: ()=>setState(()=>_current--), child: Text(s.t('back')))),
          if(_current>0) const SizedBox(width: 12),
          Expanded(child: ElevatedButton(onPressed: _next, child: Text(s.t('next'))))
        ])
      ])),
    );
  }
  void _markDone(){ _next(); }
  void _next(){ setState((){ if(_current < _steps.length-1){ _current++; } else { Navigator.of(context).pop(); } }); }
  Future<void> _speak(String text) async{
    final lang = widget.locale.languageCode=='pl' ? 'pl-PL' : 'en-US';
    await _tts.speak(text, locale: lang);
  }
}
class _StepItem{ final String key; final String image; _StepItem(this.key,this.image); }
