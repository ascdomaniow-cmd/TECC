import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../models/lesson.dart';
import '../widgets/progress_chip.dart';
import '../l10n/l10n.dart';
import 'quiz_screen.dart';

class LessonScreen extends StatelessWidget{
  final Lesson lesson; final int index; final int total; final Locale locale;
  const LessonScreen({super.key, required this.lesson, required this.index, required this.total, required this.locale});
  @override Widget build(BuildContext context){
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t(lesson.titleKey)), actions: [Padding(padding: const EdgeInsets.all(8.0), child: ProgressChip(index:index, total:total))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SvgPicture.asset(lesson.imageAsset, height: 180),
        const SizedBox(height: 16),
        ...lesson.bullets.map((b)=>Padding(padding: const EdgeInsets.symmetric(vertical: 6.0), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children:[const Text("• "), Expanded(child: Text(b))]))),
        const SizedBox(height: 24),
        ElevatedButton(onPressed: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (_)=>QuizScreen(questions: lesson.quiz, locale: locale)));
        }, child: Text(s.t('startQuiz')))
      ]),
    );
  }
}
