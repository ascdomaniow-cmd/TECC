import 'package:flutter/material.dart';
import '../models/lesson.dart';
import '../l10n/l10n.dart';

class QuizScreen extends StatefulWidget{
  final List<QuizQuestion> questions; final Locale locale;
  const QuizScreen({super.key, required this.questions, required this.locale});
  @override State<QuizScreen> createState()=>_QuizScreenState();
}
class _QuizScreenState extends State<QuizScreen>{
  int _index = 0; int _score = 0; int? _selected;
  @override Widget build(BuildContext context){
    final s = S.of(context); final q = widget.questions[_index];
    return Scaffold(
      appBar: AppBar(title: Text(s.t('quiz'))),
      body: Padding(padding: const EdgeInsets.all(16.0), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(q.q, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        ...List.generate(q.options.length, (i){
          final opt = q.options[i];
          return Padding(padding: const EdgeInsets.symmetric(vertical: 6.0), child: OutlinedButton(
            onPressed: ()=>setState(()=>_selected=i), child: Align(alignment: Alignment.centerLeft, child: Text(opt))));
        }),
        const Spacer(),
        ElevatedButton(onPressed: _selected==null? null : (){
          final correct = _selected==q.correctIndex; if(correct) _score++;
          showDialog(context: context, builder: (ctx)=>AlertDialog(
            title: Text(correct ? s.t('correct') : s.t('incorrect')),
            actions: [ TextButton(onPressed: (){
              Navigator.of(ctx).pop(); setState((){
                _selected=null;
                if(_index < widget.questions.length-1){ _index++; } else {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=>_Summary(score:_score,total: widget.questions.length)));
                }
              });
            }, child: Text(s.t('next'))) ],
          ));
        }, child: Text(s.t('next')))
      ])),
    );
  }
}
class _Summary extends StatelessWidget{
  final int score; final int total; const _Summary({required this.score, required this.total});
  @override Widget build(BuildContext context){
    final s = S.of(context);
    return Scaffold(appBar: AppBar(title: Text(s.t('summary'))), body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Text('${s.t('score')}: $score/$total', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 16),
      ElevatedButton(onPressed: ()=>Navigator.of(context).pop(), child: Text(s.t('back')))
    ])));
  }
}
