class Lesson {
  final String id;
  final String titleKey;
  final String imageAsset;
  final List<String> bullets;
  final List<QuizQuestion> quiz;
  Lesson({required this.id, required this.titleKey, required this.imageAsset, required this.bullets, required this.quiz});
  factory Lesson.fromJson(Map<String,dynamic> j)=>Lesson(
    id:j['id'], titleKey:j['titleKey'], imageAsset:j['imageAsset'],
    bullets: List<String>.from(j['bullets']),
    quiz: (j['quiz'] as List).map((e)=>QuizQuestion.fromJson(e)).toList()
  );
}
class QuizQuestion{
  final String q; final List<String> options; final int correctIndex;
  QuizQuestion({required this.q, required this.options, required this.correctIndex});
  factory QuizQuestion.fromJson(Map<String,dynamic> j)=>QuizQuestion(q:j['q'], options:List<String>.from(j['options']), correctIndex:j['correctIndex']);
}
