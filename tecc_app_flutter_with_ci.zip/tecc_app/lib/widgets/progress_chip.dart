import 'package:flutter/material.dart';
class ProgressChip extends StatelessWidget{
  final int index; final int total;
  const ProgressChip({super.key, required this.index, required this.total});
  @override Widget build(BuildContext context){
    return Container(padding: const EdgeInsets.symmetric(horizontal:12,vertical:6),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.06), borderRadius: BorderRadius.circular(20)),
      child: Text('${index+1}/$total'));
  }
}
