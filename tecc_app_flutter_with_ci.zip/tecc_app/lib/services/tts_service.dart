import 'package:flutter_tts/flutter_tts.dart';
class TtsService{
  final _tts = FlutterTts();
  Future<void> speak(String text,{String? locale}) async{
    if(locale!=null) await _tts.setLanguage(locale);
    await _tts.setSpeechRate(0.45);
    await _tts.speak(text);
  }
  Future<void> stop() async=>_tts.stop();
}
