import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/lesson.dart';
class ContentLoader{
  static Future<List<Lesson>> loadModuleM(String locale) async{
    final raw = await rootBundle.loadString('assets/content/m_module.json');
    final data = json.decode(raw) as Map<String,dynamic>;
    return (data[locale]['lessons'] as List).map((e)=>Lesson.fromJson(e)).toList();
  }
}
