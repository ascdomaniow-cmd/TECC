import 'package:flutter/material.dart';
import 'l10n/l10n.dart';
import 'theme.dart';
import 'screens/home_screen.dart';

void main(){ runApp(const TeccApp()); }
class TeccApp extends StatelessWidget{
  const TeccApp({super.key});
  @override Widget build(BuildContext context){
    return MaterialApp(
      title: 'TECC',
      theme: AppTheme.light(),
      localizationsDelegates: S.localizationsDelegates,
      supportedLocales: S.supportedLocales,
      home: const HomeScreen(),
    );
  }
}
